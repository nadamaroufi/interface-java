import java.awt.Color;




import javax.swing.JFrame;




public class Prog {

	public static void main(String[] args) {
		
		Fenetre F = new Fenetre() ;
		
		F.setVisible(true);
		
	F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	F.getContentPane().setBackground(Color.PINK);
	TraitementEtudiant etud = new TraitementEtudiant();
	}
	}


