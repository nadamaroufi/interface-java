import java.awt.Color;

import java.sql.Connection;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.ButtonGroup;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;


public class Fenetre extends JFrame {
	JLabel ListTitle;
	JLabel IDEtudiant;
	JTextField TextID;
	JLabel nomlbl;
	JTextField Textnom;
	JLabel prenomlbl;
	JTextField Textprenom;
	JLabel Sexelbl;
    JComboBox<String>Sexe;
	JLabel Age;
	JTextField TextAge; 
	JLabel NumTelbl;
	JTextField NumTel;
	JLabel Adresselbl;
	JTextField TextAdresse;
	JPanel panel;

	JLabel Niveaulbl;
	JComboBox<String> niveau;
	JLabel Filiere;
	JRadioButton rdPolytech;
	JRadioButton rdISIAM;
	JRadioButton GInfor;
	JRadioButton GElct;
	JRadioButton GIndus;
	JButton Ajouter; 
	JButton Supprimer;
	JButton Modifier;
	JList list;
	Vector<Etudiant> v;
	
	public Fenetre() {
		this.setTitle("La Gestion Des Etudiants:");
		this.setSize(750, 650);
		this.setLocation(80, 60);
	
		ListTitle = new JLabel("La Liste d'enregistrement");
		ListTitle.setBounds(400, 30, 200, 30);
		ListTitle.setFont(new Font("Arial", Font.BOLD, 14));
		ListTitle.setForeground(new Color(0, 0, 0));
		
		
		IDEtudiant = new JLabel("ID Etudiant");
		IDEtudiant.setBounds(20, 40, 120, 30);
		TextID = new JTextField();
		TextID.setBounds(120, 40, 120, 30);
		
		nomlbl = new JLabel("nom:");
		nomlbl.setBounds(20, 80, 100, 30);
		Textnom = new JTextField();
		Textnom.setBounds(120, 80, 120, 30);
		
		prenomlbl = new JLabel("prenom:");
		prenomlbl.setBounds(20, 130, 100, 30);
		Textprenom = new JTextField();
		Textprenom.setBounds(120, 130, 120, 30);
		
		Sexelbl = new JLabel("Sexe:");
	    Sexelbl.setBounds(20, 180, 100, 30);
	    Sexe = new JComboBox();
	    Sexe.setBounds(120, 180, 120, 30);
	    Sexe.addItem("Male");
	    Sexe.addItem("Female");
	    
		Age = new JLabel("Age:");
		Age.setBounds(20, 240, 100, 40);
		TextAge = new JTextField();
		TextAge.setBounds(120, 240, 120, 30);
		
		NumTelbl = new JLabel("NumTel");
		NumTelbl.setBounds(20, 290, 100, 40);
		NumTel = new JTextField();
		NumTel.setBounds(120, 290, 120, 30);
		
		Adresselbl = new JLabel("Adresse Email:");
		Adresselbl.setBounds(20, 340, 150, 40);
		TextAdresse = new JTextField();
		TextAdresse.setBounds(120, 340, 120, 30);
		
		Niveaulbl = new JLabel("niveau:");
		Niveaulbl.setBounds(20, 370, 200, 80); 
		niveau = new JComboBox<String>();
		niveau.setBounds(120, 390, 120, 40);
		niveau.addItem("1ere annee");
		niveau.addItem("2eme annee");
		niveau.addItem("3eme annee");
		niveau.addItem("4eme annee");
		niveau.addItem("5eme annee");
		
	
		
		panel = new JPanel();
		
		
		Filiere = new JLabel("Filiere:");
	    rdPolytech = new JRadioButton("POLYTECH");
	    rdISIAM = new JRadioButton("ISIAM");
	    GInfor = new JRadioButton("Génie.Inf");
	    GElct = new JRadioButton("Génie.Elect");
	    GIndus = new JRadioButton("Génie.Indus");
	    panel.add(Filiere);
	    panel.add(rdPolytech);
	    panel.add(rdISIAM);
	    panel.add(GInfor);
	    panel.add(GElct);
	    panel.add(GIndus);
	    panel.setBounds(20, 450, 450, 60);
	    panel.setBackground(Color.YELLOW);
	    
	    ButtonGroup g = new ButtonGroup();
	    g.add(rdPolytech);
	    g.add(rdISIAM);
	    g.add(GInfor);
	    g.add(GElct);
	    g.add(GIndus);
	    Ajouter = new JButton("Ajouter");
	    Ajouter.setBounds(80, 530, 100, 40);
	    Supprimer = new JButton("Supprimer");
		Supprimer.setBounds(200, 530, 100, 40);
		Modifier = new JButton("Modifier");
		Modifier.setBounds(320, 530, 100, 40);
		
		list = new JList<>();
		JScrollPane sc = new JScrollPane(list);
		sc.setBounds(320, 60, 370, 320);
		list.setBackground(Color.cyan);
		v = new Vector<Etudiant>();
		
			Ajouter.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			String Filiere="";
			if(rdPolytech.isSelected())	{
				Filiere="Polytechnique";
			}else if(rdISIAM.isSelected()) {
				Filiere="ISIAM";
			}else if(GInfor.isSelected()) {
				Filiere="GInfor";
			}else if(GElct.isSelected()) {
				Filiere="GElct";
			}else {
				Filiere="GIndus";
			}
			v.add(new Etudiant(Integer.parseInt(TextID.getText()), Textnom.getText(), Textprenom.getText(), (String) Sexe.getSelectedItem(), Integer.parseInt(TextAge.getText()), Integer.parseInt(NumTel.getText()), TextAdresse.getText(), (String) niveau.getSelectedItem(), Filiere));
			list.setListData(v);
			}
			Etudiant Etud = new Etudiant();
			TraitementEtudiant te = new TraitementEtudiant();
});
		
		Supprimer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				Etudiant Etud = (Etudiant) list.getSelectedValue();
				v.remove(Etud);
				list.setListData(v);
			}
			Etudiant Etud = new Etudiant();
			TraitementEtudiant te = new TraitementEtudiant();
		
		});
		
		Modifier.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			
				if(e.getSource()==Modifier){
					String a,b,c,d,f,g;
					a=IDEtudiant.getText();
					b=Textnom.getText();
					c=Textprenom.getText();
					d=TextAdresse.getText();
			
					g=niveau.getSelectedItem().toString();
				}
				list.setListData(v);
					
					}
			Etudiant Etud = new Etudiant();
			TraitementEtudiant te = new TraitementEtudiant();
			
				});
		
	

	Container c = this.getContentPane();
	c.setLayout(null);
	
    c.add(ListTitle);
	c.add(IDEtudiant);
	c.add(TextID);
	c.add(nomlbl);
	c.add(Textnom);
	c.add(prenomlbl);
	c.add(Textprenom);
	c.add(Sexelbl);
	c.add(Sexe);
	c.add(Age);
	c.add(TextAge);
	c.add(NumTelbl);
	c.add(NumTel);
	c.add(Adresselbl);
	c.add(TextAdresse);

	c.add(panel);
	c.add(Niveaulbl);
	c.add(niveau);
	c.add(Ajouter);
	c.add(Supprimer);
	c.add(Modifier);
	c.add(sc);
	
	}

	
}
