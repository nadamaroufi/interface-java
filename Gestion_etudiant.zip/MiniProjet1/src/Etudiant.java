

public class Etudiant {
	private int IDEtudiant;
	private String nom;
	private String prenom;
	private String Sexe;
	private int Age;
	private int NumTel;
	private String Adresse;
	private String niveau;
	private String Filiere;
	
public Etudiant() {
	
}
	public Etudiant(int IDEtudiant, String nom, String prenom, String Sexe, int Age, int NumTel, String Adresse, String niveau, String Filiere) {
		this.IDEtudiant=IDEtudiant;
		this.nom=nom;
		this.prenom=prenom;
		this.Sexe=Sexe;
		this.Age=Age;
		this.NumTel=NumTel;
		this.Adresse=Adresse;
		this.niveau=niveau;
		this.Filiere=Filiere;
	}


	public int getIDEtudiant() {
		return IDEtudiant;
	}
	public String getnom() {
		return nom;
	}
	public String getprenom() {
		return prenom;
	}
	public String getSexe() {
		return Sexe;
	}
	public int getAge() {
		return Age;
	}
	public int getNumTel() {
		return NumTel;
	}
	public String getAdresse() {
		return Adresse;
	}
	public String getniveau() {
		return niveau;
	}
	public String getFiliere() {
		return Filiere;
	}
	
	public void setIDEtudiant(int IDEtudiant) {
		this.IDEtudiant=IDEtudiant;
	}
	public void setnom(String nom) {
		this.nom=nom;
	}
	public void setprenom(String prenom) {
		this.prenom=prenom;
	}
	public void setSexe(String Sexe) {
		this.Sexe=Sexe;
	}
	public void setAge(int Age) {
		this.Age=Age;
	}
	public void setNumTel(int NumTel) {
		this.NumTel=NumTel;
	}
	public void setAdresse(String Adresse) {
		this.Adresse=Adresse;
	}
	public void setniveau(String niveau) {
		this.niveau=niveau;
	}
	public void setfiliere(String Filiere) {
		this.Filiere=Filiere;
	}
	@Override
	public String toString() {
		return "IDEtudiant= "+this.IDEtudiant+" nom= "+this.nom+" prenom= "+this.prenom+" Sexe= "+this.Sexe+" Age= "+this.Age+" NumTel = "+this.NumTel+" Adresse= "+this.Adresse+" niveau= "+this.niveau+" Filiere= "+this.Filiere+""; 
	}
}
